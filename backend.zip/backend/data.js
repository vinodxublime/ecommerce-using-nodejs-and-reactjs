// export default {
//     products: [
//         {
//             _id: "1",
//             name: "Nike Men's Regular fit T-Shirt",
//             category: "Shirt",
//             image: "/images/d1.jpg",
//             price: 35,
//             brand: " Nike",
//             rating: 3.0,
//             numReviews: 13,
//             countInStock: 6
//         },
//         {
//             _id: "2",
//             name: "Nike Men's Track Pants",
//             category: "Pants",
//             image: "/images/d2.jpg",
//             price: 50,
//             brand: " Nike",
//             rating: 4.2,
//             numReviews: 66,
//             countInStock: 8
//         },
//         {
//             _id: "3",
//             name: "Nike Men's Track Pants Gray",
//             category: "Pants",
//             image: "/images/d3.jpg",
//             price: 70,
//             brand: " Nike",
//             rating: 4,
//             numReviews: 8,
//             countInStock: 8
//         },
//         {
//             _id: "4",
//             name: "Nike Girl's Plain Regular fit T-Shirt",
//             category: "Pants",
//             image: "/images/d4.jpg",
//             price: 40,
//             brand: " Nike",
//             rating: 3.5,
//             numReviews: 18,
//             countInStock: 9
//         }
//     ]
// };
